from twitter_analysis import get_tweets


# reading text file
text = ""
text_tweets = get_tweets("maroc",1000)
length = len(text_tweets)

for i in range(0, length):
    text = text_tweets[i][0] + " " + text



fichier_texte = open("read.txt",  "w", encoding='utf-8' )
fichier_texte.write(text) 
fichier_texte.close() 

